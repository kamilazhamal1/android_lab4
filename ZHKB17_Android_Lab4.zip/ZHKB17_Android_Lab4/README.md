
Электронная книга

![Screenshot](screen1.png)

![Screenshot](screen2.png)