# TSN_DEMO_04_EBook
Электронная книга

![Screenshot](screenshot1.png)

![Screenshot](screenshot2.png)
